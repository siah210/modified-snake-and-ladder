package game;

import util.AdhocOps;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SnakesAndLadders implements GameApplication {

    Map<String, Board> games; // all the games on the app server
    public SnakesAndLadders() {
        games = new HashMap<String, Board>();
    }

// time limit 9 pm

    /**
     *
     * @param boardSize
     * @param snakes
     * @param ladders
     * @param playerIds
     * @return unique game id
     */
    @Override
    public String createGame(int boardSize, Map<Integer, Integer> snakes, Map<Integer, Integer> ladders, List<Integer> playerIds, int[] cellCapacity) {

        // if cellCaps == null
        // --> do this
        if(cellCapacity == null) {
            cellCapacity = new int[boardSize*boardSize];
            Arrays.fill(cellCapacity,1);
        }

        Board board = new Board(boardSize, snakes, ladders, playerIds, cellCapacity);
        String gameId = AdhocOps.getUniqueString();
        games.put(gameId, board);
        return gameId;
    }

    // TODO handle concurrency
    @Override
    public Boolean holdDice(String gameId, int playerId) {
        Board board = games.get(gameId);
        // invalid game id
        if(board == null || board.getGameStatus() == Status.FINISHED)
            return false;

        if(!board.isPlayerValid(playerId))
            return false;

        if(board.game_status != Status.WAITING_FOR_DICE)
            return false;

        // found a dice holder which is playerId
        board.setCurrentPlayer(playerId);

        // setting the status to playing
        board.setGameStatus(Status.PLAYING);
        return true;
    }

    @Override
    public Boolean rollDiceAndMove(String gameId, int playerId) {
        Board board = games.get(gameId);
        // invalid game id
        if(board == null || board.getGameStatus() == Status.FINISHED)
            return false;

        if(!board.isPlayerValid(playerId))
            return false;

        // we are waiting for dice
        if(board.game_status != Status.PLAYING)
            return false;

        // wrong person called roll and move
        if(board.getCurrentPlayer() != playerId)
            return false;

        return board.rollAndMakeMove();
    }
}
