package game;

import util.AdhocOps;

import java.util.List;
import java.util.Map;

public class Board {

    int current_player; // for dice strategy
    Status game_status;
    int boardSize;
    Map<Integer, Integer> snakes;
    Map<Integer, Integer> ladders;
    List<Integer> playerIds;
    Map<Integer, Integer> playerPosition;
    Cell[] board;
    int[] cellCapacity;

    // different capacities per cell will be handled in initBoard
    public Board(int boardSize, Map<Integer, Integer> snakes, Map<Integer, Integer> ladders, List<Integer> playerIds, int[] cellCapacity) {
        this.boardSize = boardSize;
        this.snakes = snakes;
        this.ladders = ladders;
        this.playerIds = playerIds;
        this.cellCapacity = cellCapacity;
        current_player = -1;
        game_status = Status.WAITING_FOR_DICE;
        board = new Cell[boardSize*boardSize];
        initBoard();
    }

    private void initBoard() {
        for(int r=0;r<boardSize*boardSize;r++) {
                board[r] = new Cell(cellCapacity[r],r);
        }

        for(int player : playerIds) {
            playerPosition.put(player, 0);
        }
    }

    public boolean rollAndMakeMove() {
        int playerId = current_player;
        // roll dice
        int dice_num = AdhocOps.rollDice();

        int curr_pos = playerPosition.get(playerId);
        int new_pos = curr_pos + dice_num;
        if(new_pos < boardSize*boardSize-1) {
            // what if it is a snake
            new_pos = snakes.getOrDefault(new_pos,new_pos);

            // what if it is a ladder
            new_pos = ladders.getOrDefault(new_pos,new_pos);

            if(board[new_pos].canPlacePlayer(playerId)) {
                playerPosition.put(playerId, new_pos);
                setGameStatus(Status.WAITING_FOR_DICE);
                return true;
            } else
                return false;

        }
        else if(new_pos == boardSize*boardSize-1) {
            // winner
            setGameStatus(Status.FINISHED);
            return true;
        }
        return false;
    }

    public Status getGameStatus() {
        return game_status;
    }

    public void setGameStatus(Status status) {
        game_status = status;
    }

    public boolean isPlayerValid(int playerId) {
        return playerIds.contains(playerId);
    }

    public int getCurrentPlayer() {
        return current_player;
    }

    public void setCurrentPlayer(int playerId) {
        current_player = playerId;
    }


}
