package util;

import java.util.Random;

public class AdhocOps {
    // 26 games at a time
    private static String current_id = "a";
    private static int current_dice = 1;

    public static String getUniqueString() {
        String now = current_id;
        current_id = Character.toString((char)(current_id.charAt(0)+1));
        return now;
    }

    public static int rollDice() {
        // generate random number
        return (current_dice++)%6 + 1;
    }
}
