package main;

//interface GameApplication {
//
//    /*
//    return unique game id
//    */
//    String createGame(int boardSize, Map<Integer, Integer> snakes, Map<Integer, Integer> ladders, List<Integer> playerIds);
//
//    /*
//    return false
//        - if player not part of this game
//        - if the game is already ended
//        - if the game id doesn't exist
//        - if dice already allocated
//    return true if hold dice is succeeded
//    */
//    Boolean holdDice(String gameId, int playerId);
//
//    /*
//    return false
//        - if any player who doesn't hold the dice calls this
//        - if dice is not allocated
//        - if the game is already ended
//        - if the game id doesn't exist
//    otherwise roll dice and move and return true
//    */
//    Boolean rollDiceAndMove(String gameId, int playerId);
//}
//


import game.GameApplication;
import game.SnakesAndLadders;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/***
 * It’s an online game and each game has multiple players and multiple games can exist at a time.
 *
 *
 * i. createGame
 * Each board is a square matrix and given board size N, you will create N*N number of cells. Each cell is numbered from 1 to N*N (array of cells) and initially all players are in position 0.
 * Snakes are represented here as Map. Key is a source cell number(from) and value is destination cell number(to). For example, it can be <10, 5> Means that snake mouth is at position 10 and snake tail is at position 5.
 * Ladders are similar to snakes but the other way around. Here it can <40, 55>
 * Return a unique game id. You can use Utils function to create unique id
 *
 *
 * ii. holdDice
 * Behaves like pressing the buzzer in a quiz competition. Like whoever presses the buzzer first, they get a chance to answer the question first. Similarly, a buzzer is exposed on each of the player’s UI, each player will simultaneously call holdDice method to acquire the dice. Allocation logic is simple that whoever reaches your system first, they get the dice.
 * Return true only If allocation is succeeded
 *
 *
 * iii. rollDiceAndMove
 * Check for valid dice holder
 * Generate random number between 1-6 which is a dice value and move player on the board, check for snakes and ladders
 * Any player reaches end position(N*N) exactly, then a player won and the game ends
 * Any player tries to move ahead of end position (> N*N), they will retain the old position only and they lost the turn
 * Only one player is allowed in a cell. But this logic can change in the future dynamically for each cell. Means that each cell can have different max capacity of players. Your code should be in an extensible way to satisfy this.
 * Once moved, release the dice for the next turn.
 *
 * classes
 * gameApplication = {board, Player[] player, current_round}
 * cell
 * board
 * player
 *
 * snl extends gameApplication
 *
 */

public class Main {
    public static void main(String[] args) {
        GameApplication gameApplication = new SnakesAndLadders();

        int boardSize = 3;
        HashMap<Integer, Integer> snakes = new HashMap<>();
        snakes.put(8, 1);
        snakes.put(6, 3);

        HashMap<Integer, Integer> ladders = new HashMap<>();
        ladders.put(5, 9);
        List<Integer> playersId = Arrays.asList(1, 2, 3);

        String gameId1 = gameApplication.createGame(boardSize, snakes, ladders, playersId, null);

        System.out.println("Game1 player1 holdDice : " + gameApplication.holdDice(gameId1, 1));
        System.out.println("Game1 player2 rollDiceAndMove : " + gameApplication.rollDiceAndMove(gameId1, 2));
//        String gameId2 = gameApplication.createGame(boardSize, snakes, ladders, playersId);
        System.out.println("Game1 player1 rollDiceAndMove : " + gameApplication.rollDiceAndMove(gameId1, 1));


//        System.out.println("Game2 player1 holdDice : " + gameApplication.holdDice(gameId2, 1));
        System.out.println("Game1 player3 holdDice : " + gameApplication.holdDice(gameId1, 3));
        System.out.println("Game1 player2 rollDiceAndMove : " + gameApplication.rollDiceAndMove(gameId1, 2));
        System.out.println("Game1 player3 rollDiceAndMove : " + gameApplication.rollDiceAndMove(gameId1, 3));

//        System.out.println("Game2 player1 rollDiceAndMove : " + gameApplication.rollDiceAndMove(gameId2, 1));
    }

}
