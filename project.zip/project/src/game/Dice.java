package game;

public class Dice {
}
