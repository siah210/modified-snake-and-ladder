package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cell {

    private int capacity;
    private Map<Integer,Boolean> players;
    int r;

    public Cell(int capacity, int r) {
        this.capacity = capacity;
        players = new HashMap<Integer, Boolean>();
        this.r = r;
    }

    public boolean canPlacePlayer(int playerId) {
        if(players.size()+1 > capacity)
            return false;
        players.put(playerId, true);
        return true;
    }

    public void removePlayer(int playerId) {
        players.remove(playerId);
    }
}


