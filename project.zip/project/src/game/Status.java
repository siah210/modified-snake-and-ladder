package game;

public enum Status {
    WAITING_FOR_DICE,
    PLAYING,
    FINISHED
}
